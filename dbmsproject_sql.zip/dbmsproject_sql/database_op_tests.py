import sqlite3

def describe_table():

    with sqlite3.connect('dbmsproject.db') as con:
        cur = con.cursor()

        cur.execute('PRAGMA table_info([AdditionalInfo])')
        row = cur.fetchall()
        print(row)

        #prints description of table housedata2

def select_all_values_table():

    with sqlite3.connect('dbmsproject.db') as con:
        cur = con.cursor()

        cur.execute("SELECT*FROM Users inner join Buyer on Users.UserId = Buyer.BuyerId where Users.UserId = 1")

        rows = cur.fetchall()
        for row in rows :
            print(row)


        #prints all the values stored in database
#select_all_values_table()

    
with sqlite3.connect('dbmsproject.db') as con:
    cur = con.cursor()
    cur.execute('SELECT Password from Users where UserId =1''')
    test = cur.fetchall()

print(test[0][0]=='password')
