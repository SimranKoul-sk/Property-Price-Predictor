import sqlite3

#establishing connection between database object and python
conn = sqlite3.connect('dbmsproject.db')

#creating reference database to work with
conn.execute('''CREATE TABLE Users(
    UserID integer PRIMARY KEY, Password text not null,BuyerId integer unique,PropertyId integer uninque, SellerId integer unique, Name text, Email text, Gender text, UserType text, City text, 
    Contact integer, unique(UserId))''')

conn.execute('''CREATE TABLE Seller(SellerId integer foreign)''')

conn.execute('''CREATE TABLE Buyer(Area_Locality text, Maxbudget integer, Minbudget integer,
BuyerId integer unique, foreign key(BuyerId) references Users(UserId))''')

conn.execute('''CREATE TABLE Property(Lot_Area integer, Utilities text, PropertyId integer, Location_property text,
Zone_property text, Street_property text, City_locality text)''')

conn.execute('''CREATE TABLE AdditionalInfo(YrSold integer, MonthSold integer,  YearBuilt integer,
    TotalBasementSF integer, GarageArea integer, GarageYearBuilt integer,
    Fireplaces integer, TotalRoomsAboveGround integer, BedroomsAboveGround integer,
    firstfloorSF integer, secodfloorSF integer)
''')
conn.commit

print('''Database has been generated. Redirect to flask app.py to insert value
           into DB for every instance''')


#database created

#NOTE : RUN ONLY ONCE :
#RUN COUNT : 1

#NOTE : CLEAN database.db : drop table housedata : status : pending


