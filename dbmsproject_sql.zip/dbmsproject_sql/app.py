from flask import Flask, render_template, request
from wtforms import Form, TextAreaField, validators
import sqlite3
import pickle
import pandas as pd
import os
import numpy as np



# Preparing the model
cur_dir = os.path.dirname(__file__)
#pickling is used to convert model stored in byte memory to conventional form
clf = pickle.load(open(os.path.join(cur_dir,
			'pkl_objects/housepricepred.pkl'), 'rb'))
        
app = Flask(__name__)


#HOME PAGE 
@app.route('/')
def index():
        return render_template('index2.html')


#TO DISPLAY VALUES BASED ON USER ID :
@app.route('/display_input', methods=['GET', 'POST']) #based on user id input : 
def display():
        return render_template('display_input.html')
        
@app.route('/display_all_values', methods=['GET', 'POST'])
def dsplay_vals():
        Uid  = int(request.form['UserId'])
        Pass = request.form['Password']
        with sqlite3.connect('dbmsproject.db') as con:
                cur = con.cursor()
                cur.execute('SELECT Password from Users where UserId =?''',(Uid,))
                correct_pass = cur.fetchall()
        if(correct_pass[0][0] == Pass):
                return render_template('display_choice.html')
        else:
                return render_template('incorrect_password.html')
                


@app.route('/display_selection', methods =['GET', 'POST'])
def action_choice_display():
        Uid = int(request.form["UserId"])
        
        choice = request.form['options'] #gives you the option the user selects
        if choice == 'option1' : #users table 
                with sqlite3.connect('dbmsproject.db') as con:
                                cur = con.cursor()
                                cur.execute("SELECT*FROM Users where UserId = ?",(Uid,))
                                rows = cur.fetchall()
                return render_template('display_all_values.html', items = rows)
        elif choice == 'option2' : #buyer table
                with sqlite3.connect('dbmsproject.db') as con:
                                cur = con.cursor()
                                cur.execute("SELECT*FROM Buyer where BuyerId = (SELECT BuyerId from Users where UserId =?)",(Uid,))
                                rows = cur.fetchall()
                return render_template('display_all_values.html', items = rows)
        elif choice =='option3' : #property table
                
                with sqlite3.connect('dbmsproject.db') as con:
                                cur = con.cursor()
                                cur.execute("SELECT*FROM Property where PropertyId = (SELECT PropertyId from Users where UserId =?)",(Uid,))
                                rows = cur.fetchall()
                return render_template('display_all_values.html', items = rows)

#TO DELETE ALL RECORDS OF INSTANCES :
@app.route("/del_all_records_auth")
def del_all_records():
        return render_template("admin_auth.html")
@app.route("/delete_all_records", methods=['GET', 'POST'])
def delete():

        username = request.form['Username']
        password = request.form['Password']

        if(username == 'admin' and password == 'password'):
                with sqlite3.connect('dbmsproject.db') as con:
                        cur = con.cursor()
                        cur.execute('''DELETE FROM Users''')
                        cur.execute('''DELETE FROM Buyer''')
                        cur.execute('''DELETE FROM Property''')
                        cur.execute('''DELETE FROM AdditionalInfo''')

                        con.commit
                return render_template('delete_message.html')

        else:
                return render_template("incorrect_password.html")


#TO DELETE RECORDS BY USER ID :
@app.route("/delete_records_uid")       
def delete_by_id():
        return render_template('delete_byrecord_input.html')
@app.route("/del", methods= ['GET', 'POST'])
def del_id():
        Uid = int(request.form['UserId'])
        Pass = request.form['Password']
        with sqlite3.connect('dbmsproject.db') as con:
                cur= con.cursor()
                cur.execute('SELECT Password from Users where UserId = ?',(Uid,))
                correct_password = cur.fetchall()
        if(correct_password[0][0] == Pass):
                with sqlite3.connect('dbmsproject.db') as con:
                        cur = con.cursor()
                        cur.execute('''DELETE FROM Users where UserId = ?''',(Uid,))
                        cur.execute('''DELETE FROM Buyer where BuyerId =?''',(Uid,))
                        cur.execute('''DELETE FROM Property where PropertyId = ?''',(Uid,))

                        con.commit
                return render_template("delete_message.html")
        else:
                return render_template("incorrect_password.html")
        


#TO UPDATE RECORDS BY USER ID : LOGIC - take authentication from the user;
        #Based on his user id delete information from USERS, BUYER and PROPERTY TABLES
                #REDIRECT user to the home page where user can create a new registration. AdditionalInfo is retained for data collection purposes.
@app.route("/update_records_uid")
def update_by_id():
        return render_template('update_byrecord_input.html')

@app.route("/update", methods= ['GET', 'POST'])
def update_action():
        Uid = int(request.form['UserId'])
        Pass = request.form['Password']

        with sqlite3.connect('dbmsproject.db') as con:
                cur= con.cursor()
                cur.execute('''SELECT Password from Users where UserId = ?''',(Uid,))
                correct_password = cur.fetchall()
        if(correct_password[0][0]==Pass):
                with sqlite3.connect('dbmsproject.db') as con:
                        cur = con.cursor()
                        cur.execute('''DELETE FROM Users where UserId = ?''',(Uid,))
                        cur.execute('''DELETE FROM Buyer where BuyerId =?''',(Uid,))
                        cur.execute('''DELETE FROM Property where PropertyId = ?''',(Uid,))

                        con.commit
                return render_template('index2.html')
        else:
                return render_template('incorrect_password.html')

#TO PREDICT RESULTS OF HOUSE PRICE
@app.route('/results', methods=['POST'])
def predict():

        #inputting general information from user to create one table for demonstration
        #using flask to serve as a backend to get data from a simple front end form
        
        UserId = int(request.form['UserId'])
        Name = request.form['Name']
        Email = request.form['Email']
        Gender = request.form['Gender']
        UserType = request.form['UserType']
        City = request.form['City']
        YrSold = int(request.form['YrSold'])
        MoSold = int(request.form['MoSold'])
        LotArea = int(request.form['LotArea'])
        YearBuilt = int(request.form['YearBuilt'])
        TotalBsmtSF = int(request.form['TotalBsmtSF'])
        GarageArea = int(request.form['GarageArea'])
        GarageYrBlt = int(request.form['GarageYrBlt'])
        Fireplaces = int(request.form['Fireplaces'])
        TotRmsAbvGrd = int(request.form['TotRmsAbvGrd'])
        BedroomAbvGrd = int(request.form['BedroomAbvGrd'])
        firstFlrSF = int(request.form['firstFlrSF'])
        secondFlrSF = int(request.form['secondFlrSF'])
        Area_locality = request.form['Area_locality']
        Maxbudget = int(request.form['Maxbudget'])
        Minbudget = int(request.form['Minbudget'])
        BuyerId = int(request.form['BuyerId'])
        Utilities = request.form['Utilities']
        PropertyId = int(request.form['PropertyId'])
        Location_property = request.form['Location_property']
        Zone_property = int(request.form['Zone_property'])
        Street_property = request.form['Street_property']
        City_locality = request.form['City_locality']
        Contact = int(request.form['Contact'])
        Password = request.form['Password']
        SellerId = request.form['SellerId']

        #storing the above data in our databases generated by the script written before after predictions  :
        #database1  - Users
        #database2  - Buyer
        #database3  - Property
        #database4  - AdditionalInfo

        input_data = [{'YrSold': YrSold, 'MoSold': MoSold, 'LotArea': LotArea, 'YearBuilt': YearBuilt, 'TotalBsmtSF': TotalBsmtSF, 'GarageArea': GarageArea,
				   'GarageYrBlt': GarageYrBlt, 'Fireplaces': Fireplaces, 'TotRmsAbvGrd' : TotRmsAbvGrd, 'BedroomAbvGrd' : BedroomAbvGrd, 'firstFlrSF' : firstFlrSF, 'secondFlrSF':secondFlrSF }]
        data = pd.DataFrame(input_data)
        result = int(clf.predict(data)[0])

        with sqlite3.connect('dbmsproject.db') as con:
                cur = con.cursor()
                            #insert values in table1
                cur.execute('''INSERT INTO Users VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(UserId,Password,BuyerId, PropertyId, SellerId,Name,Email,Gender,UserType,City,Contact))
                        #insert values in table2
                cur.execute('''INSERT INTO Buyer VALUES(?,?,?,?)''',(Area_locality, Maxbudget, Minbudget, BuyerId))
                                #insert values in table3
                cur.execute('''INSERT INTO Property VALUES(?,?,?,?,?,?,?)''',(LotArea, Utilities, PropertyId, Location_property, Zone_property, Street_property, City_locality))
                                #insert values in table4
                cur.execute('''INSERT INTO AdditionalInfo VALUES(?,?,?,?,?,?,?,?,?,?,?)''',(YrSold, MoSold, YearBuilt, TotalBsmtSF, GarageArea,GarageYrBlt,Fireplaces, TotRmsAbvGrd, BedroomAbvGrd, firstFlrSF, secondFlrSF))
                             #insert values in table5
                cur.execute('''INSERT INTO Seller VALUES(?)''',(SellerId,))
                
                con.commit
	
        return render_template('results.html', res=result)
        
	

if __name__ == '__main__':
        app.run(debug=True)
